from openai import OpenAI


class AI:

    def __init__(self, prompt):
        self.prompt = prompt

    async def askAI(self):
        client = OpenAI(
            # api_key=os.environ.get("OPENAI_API_KEY"),
            api_key="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",
        )
        completion = client.chat.completions.create(
            model="gpt-3.5-turbo",

            messages=[
                # {"role": "system", "content": "You are a poetic assistant, skilled in explaining complex programming concepts with creative flair."},
                {"role": "user", "content": self.prompt}
            ]
        )
        return completion.choices[0].message.content
