import datetime

import discord
from discord import app_commands
from discord.ext import commands, tasks
from dataclasses import dataclass
from WebScraping import Scraper
from gpt import AI

BOT_TOKEN = "MTE0NjE2MTgyODgwNDY5NDA4Ng.GFBf76.OlJGcXmufWOfmaco0jJtfpOSN430LvgQjqMFJs"
CHANNEL_ID = 996336625556652102
MAX_SESSION_TIME_MINUTES = 1


@dataclass
class Session:
    is_active: bool = False
    start_time: int = 0


bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())


# session =Session()


@bot.event
async def on_ready():
    print("Is ready!")
    channel = bot.get_channel(CHANNEL_ID)
    await channel.send("Wussup")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(e)


@bot.tree.command(name="news")
async def news(interaction: discord.Interaction, link: str):
    web_link = await get_news(link, interaction.channel.id)
    await interaction.response.send_message(web_link, ephemeral=True)
    # print(args[2])


@tasks.loop(minutes=60)
async def get_news(link, channel_id):
    media = Scraper(link)
    string = media.scrape()
    channel = bot.get_channel(channel_id)
    return string


@bot.tree.command(name="ai")
async def ai(interaction: discord.Interaction, prompt: str):
    try:

        await interaction.response.send_message("Please wait...", ephemeral=True)
        channel = bot.get_channel(interaction.channel.id)
        msg = await interaction.edit_original_response()

        result = await run_ai(prompt, interaction.channel.id)
        print(result)

        msg.delete()
        await channel.send(result)

        #
        # msg = await interaction.edit_original_response()
        # await msg.edit(content=result)
    except discord.errors.NotFound:
        # Handle NotFound error
        print("Interaction not found or expired.")
    except Exception as e:
        # Handle other exceptions
        print(f"An error occurred: {e}")


async def run_ai(prompt, channel_id):
    ai_chat = AI(prompt)
    string = await ai_chat.askAI()
    channel = bot.get_channel(channel_id)
    return string

    # await ctx.send(media.scrape())


bot.run(BOT_TOKEN)
